import 'package:cimso_development/Loading.dart';
import 'package:cimso_development/Login.dart';
import 'package:flutter/material.dart';
import 'profile.dart';
import 'reservation.dart';
import 'coupon.dart';
import 'banking.dart';
import 'Link.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Profile UI',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: Loading(), // Set ProfileScreen as the home screen initially
    );
  }
}
