import 'package:flutter/material.dart';
import 'reservation.dart';
import 'History.dart';
import 'balance.dart';
import 'profile.dart';
import 'banking.dart';
import 'SignOut.dart';

class CouponsPage extends StatefulWidget {
  @override
  _CouponsPageState createState() => _CouponsPageState();
}


class _CouponsPageState extends State<CouponsPage> {
  bool isPremium = false; // Track if the user is in "Regular" or "Premium"

  // Coupon data
  List<Map<String, String>> regularCoupons = [
    {"discount": "10%", "description": "Get 10% off your next golf booking!"},
    {"discount": "10%", "description": "10% off at the pro shop."},
    {"discount": "10%", "description": "Save 10% on your next golf lesson."},
  ];

  List<Map<String, String>> premiumCoupons = [
    {"discount": "20%", "description": "Enjoy 20% off your next membership renewal."},
    {"discount": "20%", "description": "Get 20% off premium golf accessories."},
    {"discount": "20%", "description": "Exclusive 20% discount on weekend tee times."},
  ];

  @override
  Widget build(BuildContext context) {
    List<Map<String, String>> currentCoupons = isPremium ? premiumCoupons : regularCoupons;

    return Scaffold(
      // appBar: AppBar(
      //   title: const Text("Coupons", style: TextStyle(color: Colors.purple)),
      //   backgroundColor: Colors.white,
      //   elevation: 0,
      //   centerTitle: true,
      //   iconTheme: const IconThemeData(color: Colors.purple),
      //   actions: const [
      //     Padding(
      //       padding: EdgeInsets.only(right: 16.0),
      //       child: Icon(Icons.notifications_none, color: Colors.purple),
      //     ),
      //   ],
      // ),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.nightlight_round, color: Color(0xFF383838)),
          onPressed: () {
            // Action when the leading icon is pressed
            // Navigator.push(
            //   context,
            //   MaterialPageRoute(builder: (context) => const ProfileScreen()),
            // );
          },
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.exit_to_app, color: Color(0xFF383838)),
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => SignOut()));
            },
          ),
        ],
      ),

      body: Column(
        children: [
          // Toggle buttons for Regular and Premium
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _buildTabButton("Regular", false),
                  _buildTabButton("Premium", true),
                ],
              ),
            ),
          ),

          // Coupon List
          Expanded(
            child: ListView.builder(
              itemCount: currentCoupons.length,
              itemBuilder: (context, index) {
                return _buildCouponCard(currentCoupons[index], index);
              },
            ),
          ),
        ],
      ),

      // Bottom Navigation Bar
      bottomNavigationBar: _buildBottomNavBar(),
    );
  }

  // Tab Button Builder
  Widget _buildTabButton(String text, bool premium) {
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() {
            isPremium = premium;
          });
        },
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: isPremium == premium ? Color(0xFF383838) : Colors.transparent,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(
            text,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: isPremium == premium ? Colors.white : Color(0xFF383838),
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }

  // Coupon Card Builder
  Widget _buildCouponCard(Map<String, String> coupon, int index) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Color(0xFFD0A557), // Background color
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Coupon Info
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                coupon["discount"]!,
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.white, // Set discount text color to white
                ),
              ),
              const SizedBox(height: 4),
              Text(
                coupon["description"]!,
                style: TextStyle(
                  color: Colors.white, // Set description text color to white
                ),
              ),
            ],
          ),

          // Claim Button
          ElevatedButton(
            onPressed: () {
              setState(() {
                if (isPremium) {
                  premiumCoupons.removeAt(index);
                } else {
                  regularCoupons.removeAt(index);
                }
              });
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
            ),
            child: const Text("Claim", style: TextStyle(color: Colors.black)),
          ),
        ],
      ),
    );
  }



  // Bottom Navigation Bar
  Widget _buildBottomNavBar() {
    return Container(
      margin: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 10, spreadRadius: 2, offset: Offset(0, 4)),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(30),
        child: BottomNavigationBar(
          currentIndex: 3,
          onTap: (index) {
            if (index == 0) {
              Navigator.push(context, MaterialPageRoute(builder: (context) => ProfileScreen()));
            } else if (index == 3) {
              Navigator.push(context, MaterialPageRoute(builder: (context) => BankingScreen()));
            } else if (index == 2) {
              Navigator.push(context, MaterialPageRoute(builder: (context) => MembershipScreen()));
            } else if (index == 4) {
              Navigator.push(context, MaterialPageRoute(builder: (context) => ReservationPage()));
            }
          },
          backgroundColor: Colors.white,
          selectedItemColor: Color(0xFF383838),
          unselectedItemColor: Color(0xFF383838),
          showSelectedLabels: false,
          showUnselectedLabels: false,
          type: BottomNavigationBarType.fixed,
          items: [
            BottomNavigationBarItem(icon: Icon(Icons.person_outline), label: ""),
            BottomNavigationBarItem(icon: Icon(Icons.bookmark_border), label: ""),
            BottomNavigationBarItem(
              icon: Container(
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Color(0xFF383838),
                  shape: BoxShape.circle,
                ),
                child: Icon(Icons.credit_card, color: Colors.white),
              ),
              label: "",
            ),
            BottomNavigationBarItem(icon: Icon(Icons.account_balance), label: ""),
            BottomNavigationBarItem(icon: Icon(Icons.calendar_today_outlined), label: ""),
          ],
        ),
      ),
    );
  }

}