import 'package:flutter/material.dart';
import 'profile.dart';  // Import the ProfileScreen file
import 'History.dart';
import 'coupon.dart';
import 'balance.dart';
import 'banking.dart';
import 'SignOut.dart';

class ReservationPage extends StatefulWidget {
  const ReservationPage({super.key});

  @override
  _ReservationPageState createState() => _ReservationPageState();
}

class _ReservationPageState extends State<ReservationPage> {
  // Controllers for DateRange
  TextEditingController fromDateController = TextEditingController();
  TextEditingController toDateController = TextEditingController();

  // Variable to control current view (History or Future)
  String currentView = "History";
  bool showMoreHistory = false;  // Track Show More/Show Less state for History
  bool showMoreFuture = false;   // Track Show More/Show Less state for Future

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white, // Set the background color to white
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.nightlight_round, color: Color(0xFF383838)),
          onPressed: () {},
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.exit_to_app, color: Color(0xFF383838)),
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => SignOut()));
            },
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              // TabBar with History and Future navigation
              Container(
                margin: const EdgeInsets.all(16),
                child: Material(
                  color: Colors.transparent,
                  child: DefaultTabController(
                    length: 2,
                    child: Column(
                      children: [
                        TabBar(
                          indicatorColor: Color(0xFF383838),
                          onTap: (index) {
                            setState(() {
                              currentView = index == 0 ? "History" : "Future";
                            });
                          },
                          tabs: const [
                            Tab(text: "History"),
                            Tab(text: "Future"),
                          ],
                        ),
                        const SizedBox(height: 20),
                      ],
                    ),
                  ),
                ),
              ),

              // Date Range Selection (From and To)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text("From", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    SizedBox(
                      width: 150,
                      child: TextField(
                        controller: fromDateController,
                        decoration: const InputDecoration(
                          hintText: 'Select Date',
                          border: OutlineInputBorder(),
                          contentPadding: EdgeInsets.symmetric(horizontal: 10),
                        ),
                      ),
                    ),
                    const Text("To", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    SizedBox(
                      width: 150,
                      child: TextField(
                        controller: toDateController,
                        decoration: const InputDecoration(
                          hintText: 'Select Date',
                          border: OutlineInputBorder(),
                          contentPadding: EdgeInsets.symmetric(horizontal: 10),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // Reservation View (History or Future)
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Title for Reservation View
                    Text(
                      currentView == "History" ? "Reservation History" : "Future Reservations",
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 10),

                    // Reservation Cards
                    Column(
                      children: [
                        if (currentView == "History")
                          _buildReservationCard("15.1.2025", "View Deal"),
                        if (currentView == "History")
                          _buildReservationCard("24.2.2025", "View Deal"),
                        if (currentView == "Future")
                          _buildReservationCard("8.1.2025", "Edit"),
                        if (currentView == "Future")
                          _buildReservationCard("15.3.2025", "Edit"),
                      ],
                    ),

                    // Show More / Show Less Buttons
                    if (currentView == "History")
                      _buildShowMoreButton(showMoreHistory, () {
                        setState(() {
                          showMoreHistory = !showMoreHistory;
                        });
                      }),
                    if (showMoreHistory && currentView == "History")
                      Column(
                        children: [
                          _buildReservationCard("1.4.2025", "View Deal"),
                          _buildReservationCard("10.5.2025", "View Deal"),
                        ],
                      ),

                    if (currentView == "Future")
                      _buildShowMoreButton(showMoreFuture, () {
                        setState(() {
                          showMoreFuture = !showMoreFuture;
                        });
                      }),
                    if (showMoreFuture && currentView == "Future")
                      Column(
                        children: [
                          _buildReservationCard("5.5.2025", "Edit"),
                          _buildReservationCard("20.6.2025", "Edit"),
                        ],
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),

      // Bottom Navigation Bar
      bottomNavigationBar: Container(
        margin: EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(30),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 10, spreadRadius: 2, offset: Offset(0, 4)),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(30),
          child: BottomNavigationBar(
            currentIndex: 3,
            onTap: (index) {
              if (index == 0) {
                Navigator.push(context, MaterialPageRoute(builder: (context) => ProfileScreen()));
              } else if (index == 1) {
                Navigator.push(context, MaterialPageRoute(builder: (context) => CouponsPage()));
              } else if (index == 3) {
                Navigator.push(context, MaterialPageRoute(builder: (context) => BankingScreen()));
              } else if (index == 4) {
                Navigator.push(context, MaterialPageRoute(builder: (context) => ReservationPage()));
              }
            },
            backgroundColor: Colors.white,
            selectedItemColor: Color(0xFF383838),
            unselectedItemColor: Color(0xFF383838),
            showSelectedLabels: false,
            showUnselectedLabels: false,
            type: BottomNavigationBarType.fixed,
            items: [
              BottomNavigationBarItem(icon: Icon(Icons.person_outline), label: ""),
              BottomNavigationBarItem(icon: Icon(Icons.bookmark_border), label: ""),
              BottomNavigationBarItem(
                icon: Container(
                  padding: EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Color(0xFF383838),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(Icons.credit_card, color: Colors.white),
                ),
                label: "",
              ),
              BottomNavigationBarItem(icon: Icon(Icons.account_balance), label: ""),
              BottomNavigationBarItem(icon: Icon(Icons.calendar_today_outlined), label: ""),
            ],
          ),
        ),
      ),
    );
  }

  // Method to build individual reservation card
  Widget _buildReservationCard(String date, String action) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        color: const Color(0xFFD0A557),
        elevation: 5,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(date, style: const TextStyle(color: Colors.white, fontSize: 16)),
              ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.white),
                onPressed: () {},
                child: Text(action, style: const TextStyle(color: Colors.black)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Method to build Show More / Show Less button
  Widget _buildShowMoreButton(bool showMore, VoidCallback onPressed) {
    return Center(
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(backgroundColor: Color(0xFF383838)),
        onPressed: onPressed,
        child: Text(showMore ? "Show Less" : "Show More", style: const TextStyle(color: Colors.white)),
      ),
    );
  }
}
