
import 'package:flutter/material.dart';
import 'reservation.dart';
import 'History.dart';
import 'coupon.dart';
import 'banking.dart';
import 'balance.dart';
import 'SignOut.dart';



class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.nightlight_round, color: Color(0xFF303330)),
          onPressed: () {
            // Navigator.push(
            //   context,
            //   MaterialPageRoute(builder: (context) => ProfileDarkMode()),
            // );
          },
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.exit_to_app, color: Color(0xFF383838)),
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => SignOut()));
            },
          ),
        ],
      ),

      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              const SizedBox(height: 50),

              // Profile Picture
              Stack(
                alignment: Alignment.topRight,
                children: [
                  Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.grey.shade200,
                      border: Border.all(color: Colors.white, width: 4),
                    ),
                    child: const CircleAvatar(
                      radius: 50,
                      backgroundColor: Colors.transparent,
                      child: Icon(Icons.person, size: 50, color: Colors.black54),
                    ),
                  ),
                  Positioned(
                    top: 10,
                    right: 5,
                    child: CircleAvatar(
                      radius: 12,
                      backgroundColor: Colors.white,
                      child: CircleAvatar(
                        radius: 10,
                        backgroundColor: Color(0xFF303330),
                        child: const Icon(Icons.add, size: 16, color: Colors.white),
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 10),

              // Star Rating
              const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.star, color: Color(0xFF303330), size: 20),
                  Icon(Icons.star, color: Color(0xFF303330), size: 20),
                  Icon(Icons.star, color: Color(0xFF303330), size: 20),
                  Icon(Icons.star, color: Color(0xFF303330), size: 20),
                  Icon(Icons.star_border, color: Color(0xFF303330), size: 20),
                ],
              ),

              const SizedBox(height: 8),
              const Text(
                "CUSTOMER NAME",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 5),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back_ios, size: 16, color: Color(0xFF303330)),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => AccountSettings()),
                      );
                    },
                  ),
                  const SizedBox(width: 5),
                  const Text(
                    "Membership Information",
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(width: 5),
                  IconButton(
                    icon: const Icon(Icons.arrow_forward_ios, size: 16, color: Color(0xFF303330)),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => Personal()),
                      );
                    },
                  ),
                ],
              ),

              const SizedBox(height: 15),

              // Membership Cards
              _buildInfoCard("MEMBERSHIP", "ACTIVE", Color(0xD0D0A557)),
              _buildInfoCard("SUBSCRIPTION", "PREMIUM", Color(0xFF303330)),
              _buildInfoCard("EXPIRATION DATE", "24/3/2025", Color(0xD0D0A557)),

              const SizedBox(height: 30),
            ],
          ),
        ),
      ),

      bottomNavigationBar: Container(
        margin: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(30),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 10,
              spreadRadius: 2,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(30),
          child: BottomNavigationBar(
            backgroundColor: Colors.white,
            selectedItemColor: Color(0xFF303330),
            unselectedItemColor: const Color(0xFF383838),
            showSelectedLabels: false,
            showUnselectedLabels: false,
            type: BottomNavigationBarType.fixed,
            items: [
              const BottomNavigationBarItem(
                icon: Icon(Icons.person_outline, color: Color(0xFF383838)),
                label: "",
              ),
              const BottomNavigationBarItem(
                icon: Icon(Icons.bookmark_border, color: Color(0xFF383838)),
                label: "",
              ),
              BottomNavigationBarItem(
                icon: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: Color(0xFF383838),
                  ),
                  child: const Icon(Icons.credit_card, color: Colors.white),
                ),
                label: "",
              ),
              const BottomNavigationBarItem(
                icon: Icon(Icons.account_balance, color: Color(0xFF383838)),
                label: "",
              ),
              const BottomNavigationBarItem(
                icon: Icon(Icons.calendar_today_outlined, color: Color(0xFF383838)),
                label: "",
              ),
            ],
            onTap: (index) {
              if (index == 0) {
                // Stay on ProfileScreen
              } else if (index == 1) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => CouponsPage()),
                );
              } else if (index == 2) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MembershipScreen()),
                );
              } else if (index == 3) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => BankingScreen()),
                );
              } else if (index == 4) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ReservationPage()),
                );
              }
            },
          ),
        ),
      ),
    );
  }

  Widget _buildInfoCard(String title, String value, Color color) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 12), // Increased vertical margin
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24), // Increased padding
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: color, // Solid color
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 16, // Increased font size
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 16, // Increased font size
            ),
          ),
        ],
      ),
    );
  }
}


class AccountSettings extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.nightlight_round, color: Color(0xFF303330)),
          onPressed: () {
            // Action when the leading icon is pressed
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_none, color: Color(0xFF303330)),
            onPressed: () {
              // Action when the notification icon is pressed
            },
          ),
          const SizedBox(width: 16),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              const SizedBox(height: 50),
              _buildProfileHeader('Account Setting', context),
              _buildInfoCard(Icons.person, 'Account Information', Color(0xFF303330), 0),
              _buildInfoCard(Icons.phone, 'Contact Support', Color(0xFF303330), 1),
              _buildInfoCard(Icons.card_membership, 'Membership', Color(0xFF303330), 2),
              _buildInfoCard(Icons.shield_moon, 'Security', Color(0xFF303330), 3),
              _buildInfoCard(Icons.verified_user, 'Account Activation', Color(0xFF303330), 4),
            ],
          ),
        ),
      ),
      bottomNavigationBar: Container(
        margin: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(30),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 10,
              spreadRadius: 2,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(30),
          child: BottomNavigationBar(
            backgroundColor: Colors.white,
            selectedItemColor: Color(0xFF303330),
            unselectedItemColor: const Color(0xFF303330),
            showSelectedLabels: false,
            showUnselectedLabels: false,
            type: BottomNavigationBarType.fixed,
            items: [
              const BottomNavigationBarItem(
                icon: Icon(Icons.person_outline, color: Color(0xFF303330)),
                label: "",
              ),
              const BottomNavigationBarItem(
                icon: Icon(Icons.bookmark_border, color: Color(0xFF303330)),
                label: "",
              ),
              BottomNavigationBarItem(
                icon: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: Color(0xFF303330),
                  ),
                  child: const Icon(Icons.credit_card, color: Colors.white),
                ),
                label: "",
              ),
              const BottomNavigationBarItem(
                icon: Icon(Icons.account_balance, color: Color(0xFF303330)),
                label: "",
              ),
              const BottomNavigationBarItem(
                icon: Icon(Icons.calendar_today_outlined, color: Color(0xFF303330)),
                label: "",
              ),
            ],
            onTap: (index) {
              if (index == 0) {
                // Stay on ProfileScreen
              } else if (index == 1) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => CouponsPage()),
                );
              } else if (index == 2) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MembershipScreen()),
                );
              } else if (index == 3) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => BankingScreen()),
                );
              } else if (index == 4) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ReservationPage()),
                );
              }
            },
          ),
        ),
      ),
    );
  }

  Widget _buildProfileHeader(String title, BuildContext context) {
    return Column(
      children: [
        Stack(
          alignment: Alignment.topRight,
          children: [
            Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.grey.shade200,
                border: Border.all(color: Colors.white, width: 4),
              ),
              child: const CircleAvatar(
                radius: 50,
                backgroundColor: Colors.transparent,
                child: Icon(Icons.person, size: 50, color: Colors.black54),
              ),
            ),
            Positioned(
              top: 10,
              right: 5,
              child: CircleAvatar(
                radius: 12,
                backgroundColor: Colors.white,
                child: CircleAvatar(
                  radius: 10,
                  backgroundColor: Colors.black87,
                  child: const Icon(Icons.add, size: 16, color: Colors.white),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.star, color: Color(0xFF303330), size: 20),
            Icon(Icons.star, color: Color(0xFF303330), size: 20),
            Icon(Icons.star, color: Color(0xFF303330), size: 20),
            Icon(Icons.star, color: Color(0xFF303330), size: 20),
            Icon(Icons.star_border, color: Color(0xFF303330), size: 20),
          ],
        ),
        const SizedBox(height: 5),
        const Text(
          "CUSTOMER NAME",
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 5),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            IconButton(
              icon: const Icon(Icons.arrow_back_ios, size: 16, color: Color(0xFF303330)),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Personal()),
                );
              },
            ),
            const SizedBox(width: 10),
            const Text(
              "Account Setting",
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
            ),
            const SizedBox(width: 10),
            IconButton(
              icon: const Icon(Icons.arrow_forward_ios, size: 16, color: Color(0xFF303330)),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ProfileScreen()),
                );
              },
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildInfoCard(IconData icon, String title, Color color, int index) {
    List<Color> panelColors = [
      Color(0xFF303330), // Dark Gray
      Color(0xFFD0A557), // Golden
    ];

    // Alternating color logic for the background
    Color panelColor = panelColors[index % panelColors.length];

    // List of circle background colors for the icon
    List<Color> circleColors = [Colors.red, Colors.purple, Colors.green, Colors.yellow, Colors.blue];

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: panelColor, // No opacity applied, keep the color vivid
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: [
          CircleAvatar(
            backgroundColor: circleColors[index % circleColors.length],  // Keep the alternating circle colors
            child: Icon(
              icon,
              color: Colors.white, // Icon remains white
            ),
          ),
          const SizedBox(width: 16),
          Text(
            title,
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold), // Font color changed to white
          ),
        ],
      ),
    );
  }




}


class Personal extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.nightlight_round, color: Color(0xFF303330)),
          onPressed: () {
            // Action when the leading icon is pressed
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_none, color: Color(0xFF303330)),
            onPressed: () {
              // Action when the notification icon is pressed
            },
          ),
          const SizedBox(width: 16),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              const SizedBox(height: 50),
              _buildProfileHeader('Personal Information', context),
              _buildInfoCard(Icons.person, 'Username', Color(0xFF303330), 0),
              _buildInfoCard(Icons.badge, 'UserID', Color(0xFF303330), 1),
              _buildInfoCard(Icons.email, 'Email Address', Color(0xFF303330), 2),
              _buildInfoCard(Icons.phone, 'Phone Number', Color(0xFF303330), 3),
              _buildInfoCard(Icons.contact_emergency, 'Emergency Contact', Color(0xFF303330), 4),
            ],
          ),
        ),
      ),
      bottomNavigationBar: Container(
        margin: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(30),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 10,
              spreadRadius: 2,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(30),
          child: BottomNavigationBar(
            backgroundColor: Colors.white,
            selectedItemColor: Color(0xFF303330),
            unselectedItemColor: const Color(0xFF303330),
            showSelectedLabels: false,
            showUnselectedLabels: false,
            type: BottomNavigationBarType.fixed,
            items: [
              const BottomNavigationBarItem(
                icon: Icon(Icons.person_outline, color: Color(0xFF303330)),
                label: "",
              ),
              const BottomNavigationBarItem(
                icon: Icon(Icons.bookmark_border, color: Color(0xFF303330)),
                label: "",
              ),
              BottomNavigationBarItem(
                icon: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: Color(0xFF303330),
                  ),
                  child: const Icon(Icons.credit_card, color: Colors.white),
                ),
                label: "",
              ),
              const BottomNavigationBarItem(
                icon: Icon(Icons.account_balance, color: Color(0xFF303330)),
                label: "",
              ),
              const BottomNavigationBarItem(
                icon: Icon(Icons.calendar_today_outlined, color: Color(0xFF303330)),
                label: "",
              ),
            ],
            onTap: (index) {
              if (index == 0) {
                // Stay on ProfileScreen
              } else if (index == 1) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => CouponsPage()),
                );
              } else if (index == 2) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MembershipScreen()),
                );
              } else if (index == 3) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => BankingScreen()),
                );
              } else if (index == 4) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ReservationPage()),
                );
              }
            },
          ),
        ),
      ),
    );
  }

  Widget _buildProfileHeader(String title, BuildContext context) {
    return Column(
      children: [
        Stack(
          alignment: Alignment.topRight,
          children: [
            Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.grey.shade200,
                border: Border.all(color: Colors.white, width: 4),
              ),
              child: const CircleAvatar(
                radius: 50,
                backgroundColor: Colors.transparent,
                child: Icon(Icons.person, size: 50, color: Colors.black54),
              ),
            ),
            Positioned(
              top: 10,
              right: 5,
              child: CircleAvatar(
                radius: 12,
                backgroundColor: Colors.white,
                child: CircleAvatar(
                  radius: 10,
                  backgroundColor: Colors.black87,
                  child: const Icon(Icons.add, size: 16, color: Colors.white),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.star, color: Color(0xFF303330), size: 20),
            Icon(Icons.star, color: Color(0xFF303330), size: 20),
            Icon(Icons.star, color: Color(0xFF303330), size: 20),
            Icon(Icons.star, color: Color(0xFF303330), size: 20),
            Icon(Icons.star_border, color: Color(0xFF303330), size: 20),
          ],
        ),
        const SizedBox(height: 5),
        const Text(
          "CUSTOMER NAME",
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 5),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            IconButton(
              icon: const Icon(Icons.arrow_back_ios, size: 16, color: Color(0xFF303330)),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ProfileScreen()),
                );
              },
            ),
            const SizedBox(width: 10),
            const Text(
              "Personal Information",
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
            ),
            const SizedBox(width: 10),
            IconButton(
              icon: const Icon(Icons.arrow_forward_ios, size: 16, color: Color(0xFF303330)),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => AccountSettings()),
                );
              },
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildInfoCard(IconData icon, String title, Color color, int index) {
    List<Color> panelColors = [
      Color(0xFF303330), // Dark Gray
      Color(0xFFD0A557), // Golden
    ];

    // Alternating color logic for the background
    Color panelColor = panelColors[index % panelColors.length];

    // List of circle background colors for the icon
    List<Color> circleColors = [Colors.red, Colors.purple, Colors.green, Colors.yellow, Colors.blue];

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: panelColor, // No opacity applied, keep the color vivid
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: [
          CircleAvatar(
            backgroundColor: circleColors[index % circleColors.length],  // Keep the alternating circle colors
            child: Icon(
              icon,
              color: Colors.white, // Icon remains white
            ),
          ),
          const SizedBox(width: 16),
          Text(
            title,
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold), // Font color changed to white
          ),
        ],
      ),
    );
  }

}




