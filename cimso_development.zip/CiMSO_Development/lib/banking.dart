import 'package:flutter/material.dart';
import 'reservation.dart';
import 'History.dart';
import 'coupon.dart';
import 'balance.dart';
import 'profile.dart';
import 'TopUpPage.dart';
import 'Credit.dart';
import 'Link.dart';
import 'SignOut.dart';

class BankingScreen extends StatefulWidget {
  @override
  _BankingScreenState createState() => _BankingScreenState();
}

class _BankingScreenState extends State<BankingScreen> {
  bool expanded = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text('Banking', style: TextStyle(color: Colors.black)),
        leading: IconButton(
          icon: Icon(Icons.nightlight_round, color: Colors.black),
          onPressed: () {},
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.exit_to_app, color: Colors.black),
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => SignOut()));
            },
          ),
        ],
      ),
      body: Column(
        children: [
          _buildBankingOptions(),
          Expanded(child: _buildNewsSection()), // Ensuring news section fills remaining space
        ],
      ),
      bottomNavigationBar: _buildBottomNavBar(),
    );
  }

  Widget _buildBankingOptions() {
    return Container(
      margin: EdgeInsets.all(16),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 10, spreadRadius: 2, offset: Offset(0, 4)),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Banking', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black)),
              GestureDetector(
                onTap: () {
                  setState(() {
                    expanded = !expanded;
                  });
                },
                child: Text(expanded ? 'Show Less' : 'See More',
                    style: TextStyle(color: Color(0xFF383838), fontWeight: FontWeight.bold)),
              ),
            ],
          ),
          SizedBox(height: 10),
          _buildBankingIcons(),
        ],
      ),
    );
  }

  Widget _buildBankingIcons() {
    List<Map<String, dynamic>> options = [
      {'label': 'Top Up', 'icon': Icons.add_circle, 'screen': TopUpScreen()},
      {'label': 'Transfer', 'icon': Icons.swap_horiz,  'screen': TopUpScreen()},
      {'label': 'Credit', 'icon': Icons.credit_card, 'screen': CreditScreen()},
      {'label': 'Link Card', 'icon': Icons.link, 'screen': LinkScreen()},
    ];

    if (expanded) {
      options.addAll([
        {'label': 'Balance', 'icon': Icons.account_balance_wallet, 'screen': MembershipScreen()},
        {'label': 'Statement', 'icon': Icons.receipt_long, 'screen': MembershipScreen()},
        {'label': 'History', 'icon': Icons.history, 'screen': HistoryScreen()},
        {'label': 'Reservation', 'icon': Icons.event, 'screen': ReservationPage()},
      ]);
    }

    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: options.sublist(0, 4).map((option) {
            return _buildBankingIcon(option);
          }).toList(),
        ),
        if (expanded)
          SizedBox(height: 20),
        if (expanded)
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: options.sublist(4).map((option) {
              return _buildBankingIcon(option);
            }).toList(),
          ),
      ],
    );
  }

  Widget _buildBankingIcon(Map<String, dynamic> option) {
    return GestureDetector(
      onTap: () {
        Navigator.push(context, MaterialPageRoute(builder: (context) => option['screen']));
      },
      child: Column(
        children: [
          CircleAvatar(
            backgroundColor: Color(0xFF383838),
            radius: 28,
            child: Icon(option['icon'], color: Colors.white, size: 30),
          ),
          SizedBox(height: 5),
          Container(
            width: 80,
            child: Text(
              option['label'],
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNewsSection() {
    return ListView(
      children: [
        _buildNewsCard('assets/images/foundation.jpg', 'FOUNDATION'),
        _buildNewsCard('assets/images/golf.jpg', 'IS GOLFING GOOD?'),
        _buildNewsCard('assets/images/private_time.jpg', 'PRIVATE TIME'),
      ],
    );
  }

  Widget _buildNewsCard(String imagePath, String title) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
        image: DecorationImage(image: AssetImage(imagePath), fit: BoxFit.cover),
      ),
      height: 150,
      alignment: Alignment.bottomLeft,
      padding: EdgeInsets.all(10),
      child: Text(title, style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
    );
  }

  Widget _buildBottomNavBar() {
    return Container(
      margin: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 10, spreadRadius: 2, offset: Offset(0, 4)),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(30),
        child: BottomNavigationBar(
          currentIndex: 3,
          onTap: (index) {
            if (index == 0) {
              Navigator.push(context, MaterialPageRoute(builder: (context) => ProfileScreen()));
            } else if (index == 1) {
              Navigator.push(context, MaterialPageRoute(builder: (context) => CouponsPage()));
            } else if (index == 2) {
              Navigator.push(context, MaterialPageRoute(builder: (context) => MembershipScreen()));
            } else if (index == 4) {
              Navigator.push(context, MaterialPageRoute(builder: (context) => ReservationPage()));
            }
          },
          backgroundColor: Colors.white,
          selectedItemColor: Color(0xFF383838),
          unselectedItemColor: Color(0xFF383838),
          showSelectedLabels: false,
          showUnselectedLabels: false,
          type: BottomNavigationBarType.fixed,
          items: [
            BottomNavigationBarItem(icon: Icon(Icons.person_outline), label: ""),
            BottomNavigationBarItem(icon: Icon(Icons.bookmark_border), label: ""),
            BottomNavigationBarItem(
              icon: Container(
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Color(0xFF383838),
                  shape: BoxShape.circle,
                ),
                child: Icon(Icons.credit_card, color: Colors.white),
              ),
              label: "",
            ),
            BottomNavigationBarItem(icon: Icon(Icons.account_balance), label: ""),
            BottomNavigationBarItem(icon: Icon(Icons.calendar_today_outlined), label: ""),
          ],
        ),
      ),
    );
  }
}


