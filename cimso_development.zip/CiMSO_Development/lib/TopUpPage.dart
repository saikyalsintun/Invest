import 'package:flutter/material.dart';
import 'banking.dart';


class TopUpScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Color(0xFF383838),
        leading: IconButton(
          icon: Icon(Icons.nightlight_round, color: Colors.white),
          onPressed: () {},
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.exit_to_app, color: Colors.white),
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => SignOutPage()));
            },
          ),
        ],
        title: Text("Top Up", style: TextStyle(color: Colors.white)),
        centerTitle: true,
        elevation: 0,
      ),
      body: Column(
        children: [
          Container(
            color: Color(0xFF383838),
            padding: EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("From:", style: TextStyle(color: Colors.white)),
                TextField(decoration: InputDecoration(filled: true, fillColor: Colors.white)),
                SizedBox(height: 10),
                Text("To:", style: TextStyle(color: Colors.white)),
                TextField(decoration: InputDecoration(filled: true, fillColor: Colors.white)),
              ],
            ),
          ),
          Expanded(
            child: Padding(
              padding: EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  DropdownButtonFormField(
                    decoration: InputDecoration(labelText: "Wallet Type"),
                    items: [
                      DropdownMenuItem(child: Text("Option 1"), value: "Option 1"),
                      DropdownMenuItem(child: Text("Option 2"), value: "Option 2"),
                      DropdownMenuItem(child: Text("Option 3"), value: "Option 3"),
                    ],
                    onChanged: (value) {},
                  ),
                  SizedBox(height: 20),
                  Container(
                    padding: EdgeInsets.all(16),
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(8)),
                    child: Row(
                      children: [
                        Icon(Icons.account_balance_wallet, color: Color(0xFF383838)),
                        SizedBox(width: 10),
                        Text("Your Balance:", style: TextStyle(fontSize: 16, color: Color(0xFF383838))),
                        Spacer(),
                        Text("300,000", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF383838))),
                      ],
                    ),
                  ),
                  SizedBox(height: 20),
                  Text("Amount:"),
                  TextField(decoration: InputDecoration(filled: true, fillColor: Colors.white)),
                  SizedBox(height: 20),
                  Center(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: Color(0xFF383838), foregroundColor: Colors.white),
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => TopUp2()));
                      },
                      child: Text("Make Payment"),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}


class TopUp2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Color(0xFF383838),
        leading: IconButton(
          icon: Icon(Icons.nightlight_round, color: Colors.white),
          onPressed: () {},
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.exit_to_app, color: Colors.white),
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => SignOutPage()));
            },
          ),
        ],
        title: Text("Top Up", style: TextStyle(color: Colors.white)),
        centerTitle: true,
        elevation: 0,
      ),
      body: Column(
        children: [
          Container(
            color: Color(0xFF383838),
            padding: EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("From:", style: TextStyle(color: Colors.white)),
                TextField(decoration: InputDecoration(filled: true, fillColor: Colors.white)),
                SizedBox(height: 10),
                Text("Payment Detail:", style: TextStyle(color: Colors.white)),
                Text("Transaction Date:", style: TextStyle(color: Colors.white)),
                Text("Transaction ID:", style: TextStyle(color: Colors.white)),
                Text("Note:", style: TextStyle(color: Colors.white)),
                SizedBox(height: 10),
                Text("To:", style: TextStyle(color: Colors.white)),
                TextField(decoration: InputDecoration(filled: true, fillColor: Colors.white)),
                SizedBox(height: 10),
                Text("Amount:", style: TextStyle(color: Colors.white)),
                TextField(decoration: InputDecoration(filled: true, fillColor: Colors.white)),
                SizedBox(height: 10),  // 10px space
              ],
            ),
          ),
          Container(
            color: Colors.white,
            padding: EdgeInsets.all(16),
            child: Center(
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Color(0xFF383838), foregroundColor: Colors.white),
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => TopUp3()));
                },
                child: Text("Confirm"),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class TopUp3 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Color(0xFF383838),
        leading: IconButton(
          icon: Icon(Icons.nightlight_round, color: Colors.white),
          onPressed: () {},
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.exit_to_app, color: Colors.white),
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => SignOutPage()));
            },
          ),
        ],
        title: Text("Payment Successful", style: TextStyle(color: Colors.white)),
        centerTitle: true,
        elevation: 0,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Success Message Section
          Container(
            color: Colors.white,
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 32),
            child: Column(
              children: [
                Icon(
                  Icons.check_circle_outline, // Success check icon
                  color: Color(0xFF383838),
                  size: 80,
                ),
                SizedBox(height: 20),
                Text(
                  "Your payment has been successfully processed!",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0xFF383838),
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 20),
                Text(
                  "Transaction ID: 1234567890",
                  style: TextStyle(color: Color(0xFF383838), fontSize: 16),
                ),
              ],
            ),
          ),

          // Back Button Section
          Container(
            color: Colors.white,
            padding: EdgeInsets.all(16),
            child: Center(
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF383838),
                  foregroundColor: Colors.white,
                ),
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => BankingScreen()));
                },
                child: Text("Back to Banking"),
              ),
            ),
          ),
        ],
      ),
    );
  }
}


class SignOutPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(child: Text("Signed Out", style: TextStyle(color: Color(0xFF383838), fontSize: 24))),
    );
  }
}
