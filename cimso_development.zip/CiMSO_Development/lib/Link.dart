import 'package:flutter/material.dart';
import 'profile.dart';
import 'reservation.dart';
import 'coupon.dart';
import 'banking.dart';
import 'balance.dart';

class LinkScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.nightlight_round, color: Color(0xFF383838)),
          onPressed: () {
            // Implement dark mode toggle here
          },
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.exit_to_app, color: Color(0xFF383838)),
            onPressed: () {
              // Implement sign-out functionality here
            },
          ),
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text("Link with Banking", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          SizedBox(height: 20),
          Container(
            padding: EdgeInsets.all(20),
            margin: EdgeInsets.symmetric(horizontal: 20),
            decoration: BoxDecoration(
              color: Color(0xFF383838),
              borderRadius: BorderRadius.circular(15),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("4563 1245 6426 3049", style: TextStyle(color: Colors.white, fontSize: 18)),
                  SizedBox(height: 5),
                  Text("Valid till 09/25", style: TextStyle(color: Colors.white70, fontSize: 14)),
                  SizedBox(height: 20),
                  Row(
                    children: [
                      Icon(Icons.account_balance_wallet, color: Colors.white),
                      SizedBox(width: 10),
                      Text("Chanin Kul", style: TextStyle(color: Colors.white, fontSize: 16)),
                    ],
                ),
              ],

            ),

          ),
          SizedBox(height: 20),
          Container(
            width: double.infinity,
            margin: EdgeInsets.symmetric(horizontal: 20),
            child: ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => AccountTypePage()),
                );
              },
              child: Icon(Icons.add, size: 30, color: Colors.white),
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFF383838),
                padding: EdgeInsets.symmetric(vertical: 20),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
              ),
            ),
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ProfileScreen()),
              );
            },
            child: Text("Back to Profile"),
            style: ElevatedButton.styleFrom(
              backgroundColor: Color(0xFF383838),
              foregroundColor: Colors.white,
            ),
          ),
        ],
      ),
      bottomNavigationBar: Container(
        margin: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(30),
          boxShadow: [
            BoxShadow(
              color: Color(0xFF383838).withOpacity(0.1),
              blurRadius: 10,
              spreadRadius: 2,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(30),
          child: BottomNavigationBar(
            backgroundColor: Colors.white,
            selectedItemColor: Color(0xFF303330),
            unselectedItemColor: const Color(0xFF383838),
            showSelectedLabels: false,
            showUnselectedLabels: false,
            type: BottomNavigationBarType.fixed,
            items: [
              const BottomNavigationBarItem(
                icon: Icon(Icons.person_outline, color: Color(0xFF383838)),
                label: "",
              ),
              const BottomNavigationBarItem(
                icon: Icon(Icons.bookmark_border, color: Color(0xFF383838)),
                label: "",
              ),
              BottomNavigationBarItem(
                icon: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: Color(0xFF383838),
                  ),
                  child: const Icon(Icons.credit_card, color: Colors.white),
                ),
                label: "",
              ),
              const BottomNavigationBarItem(
                icon: Icon(Icons.account_balance, color: Color(0xFF383838)),
                label: "",
              ),
              const BottomNavigationBarItem(
                icon: Icon(Icons.calendar_today_outlined, color: Color(0xFF383838)),
                label: "",
              ),
            ],
            onTap: (index) {
              if (index == 0) {
                // Stay on ProfileScreen
              } else if (index == 1) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => CouponsPage()),
                );
              } else if (index == 2) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MembershipScreen()),
                );
              } else if (index == 3) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => BankingScreen()),
                );
              } else if (index == 4) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ReservationPage()),
                );
              }
            },
          ),
        ),
      ),
    );
  }
}

class AccountTypePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.nightlight_round, color: Color(0xFF383838)),
          onPressed: () {},
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.exit_to_app, color: Color(0xFF383838)),
            onPressed: () {},
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text("Select Card Type", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _buildCardTypeButton("VISA"),
                _buildCardTypeButton("PAYPAL"),
                _buildCardTypeButton("OTHERS"),
              ],
            ),
            SizedBox(height: 20),
            _buildTextField("Card Number"),
            _buildTextField("User Name"),
            _buildTextField("Address"),
            Row(
              children: [
                Expanded(flex: 3, child: _buildTextField("Zip Code")),
                SizedBox(width: 10),
                Expanded(flex: 2, child: _buildDropdownField("Country")),
              ],
            ),
            Row(
              children: [
                Expanded(flex: 3, child: _buildTextField("Exp Date")),
                SizedBox(width: 10),
                Expanded(flex: 2, child: _buildTextField("CVV")),
              ],
            ),
            SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF383838),
                  padding: EdgeInsets.symmetric(vertical: 15),
                ),
                onPressed: () {
                  Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => LinkScreen1()),
                );},
                child: Text("Add", style: TextStyle(color: Colors.white)),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        margin: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(30),
          boxShadow: [
            BoxShadow(
              color: Color(0xFF383838).withOpacity(0.1),
              blurRadius: 10,
              spreadRadius: 2,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(30),
          child: BottomNavigationBar(
            backgroundColor: Colors.white,
            selectedItemColor: Color(0xFF303330),
            unselectedItemColor: const Color(0xFF383838),
            showSelectedLabels: false,
            showUnselectedLabels: false,
            type: BottomNavigationBarType.fixed,
            items: [
              const BottomNavigationBarItem(
                icon: Icon(Icons.person_outline, color: Color(0xFF383838)),
                label: "",
              ),
              const BottomNavigationBarItem(
                icon: Icon(Icons.bookmark_border, color: Color(0xFF383838)),
                label: "",
              ),
              BottomNavigationBarItem(
                icon: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: Color(0xFF383838),
                  ),
                  child: const Icon(Icons.credit_card, color: Colors.white),
                ),
                label: "",
              ),
              const BottomNavigationBarItem(
                icon: Icon(Icons.account_balance, color: Color(0xFF383838)),
                label: "",
              ),
              const BottomNavigationBarItem(
                icon: Icon(Icons.calendar_today_outlined, color: Color(0xFF383838)),
                label: "",
              ),
            ],
            onTap: (index) {
              if (index == 0) {
                // Stay on ProfileScreen
              } else if (index == 1) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => CouponsPage()),
                );
              } else if (index == 2) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MembershipScreen()),
                );
              } else if (index == 3) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => BankingScreen()),
                );
              } else if (index == 4) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ReservationPage()),
                );
              }
            },
          ),
        ),
      ), // Navigation bar
    );
  }

  Widget _buildCardTypeButton(String text) {
    Color backgroundColor;
    BorderSide borderSide = BorderSide.none;

    // Determine background color and border side based on the text (card type)
    if (text == "PAYPAL") {
      backgroundColor = Colors.transparent;  // No fill color for PayPal
      borderSide = BorderSide(color: Color(0xFF383838), width: 2);  // Border only for PayPal
    } else if (text == "VISA" || text == "OTHERS") {
      backgroundColor = Color(0xFF383838);  // Dark background for Visa and Others
      borderSide = BorderSide.none;  // No border for Visa and Others
    }

    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 8), // Adjust padding to prevent overflow
      child: ElevatedButton(
        style: ButtonStyle(
          backgroundColor: MaterialStateProperty.all(Color(0xFF383838)),  // Set dynamic background color
          padding: MaterialStateProperty.all(EdgeInsets.symmetric(horizontal: 30, vertical: 16)), // Adjusted padding for a cleaner look
          shape: MaterialStateProperty.all(
            RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(18),  // Smoother corner radius
              side: borderSide,  // Border only for PayPal
            ),
          ),
          textStyle: MaterialStateProperty.all(TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: text == "PAYPAL" ? Color(0xFF383838) : Colors.white,
          )),  // Adjusted font size for better visibility
        ),
        onPressed: () {
          // Action on button press
          print('$text button pressed');
        },
        child: Text(text),
      ),
    );
  }

  Widget _buildTextField(String hintText) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 5),
      child: TextField(
        decoration: InputDecoration(
          hintText: hintText,
          filled: true,
          fillColor: Colors.grey[200],
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
        ),
      ),
    );
  }

  Widget _buildDropdownField(String hintText) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 5),
      child: DropdownButtonFormField(
        decoration: InputDecoration(
          hintText: hintText,
          filled: true,
          fillColor: Colors.grey[200],
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
        ),
        items: ["USA", "Canada", "UK", "India"]
            .map((e) => DropdownMenuItem(value: e, child: Text(e)))
            .toList(),
        onChanged: (value) {},
      ),
    );
  }
}

class LinkScreen1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.nightlight_round, color: Color(0xFF383838)),
          onPressed: () {
            // Implement dark mode toggle here
          },
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.exit_to_app, color: Color(0xFF383838)),
            onPressed: () {
              // Implement sign-out functionality here
            },
          ),
        ],
      ),
      body: SingleChildScrollView(  // Wrap the body with SingleChildScrollView
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text("Link with Banking", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 20),

            // First Card: Bank Info
            Container(
              padding: EdgeInsets.all(20),
              margin: EdgeInsets.symmetric(horizontal: 20),
              decoration: BoxDecoration(
                color: Color(0xFF383838),
                borderRadius: BorderRadius.circular(15),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("4563 1245 6426 3049", style: TextStyle(color: Colors.white, fontSize: 18)),
                  SizedBox(height: 5),
                  Text("Valid till 09/25", style: TextStyle(color: Colors.white70, fontSize: 14)),
                  SizedBox(height: 20),
                  Row(
                    children: [
                      Icon(Icons.account_balance_wallet, color: Colors.white),
                      SizedBox(width: 10),
                      Text("Chanin Kul", style: TextStyle(color: Colors.white, fontSize: 16)),
                    ],
                  ),
                ],
              ),
            ),

            SizedBox(height: 20),

            // Second Card: Link to Profile (or any other action)
            Container(
              padding: EdgeInsets.all(20),
              margin: EdgeInsets.symmetric(horizontal: 20),
              decoration: BoxDecoration(
                color: Color(0xFF383838),
                borderRadius: BorderRadius.circular(15),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Account Name", style: TextStyle(color: Colors.white, fontSize: 18)),
                  SizedBox(height: 5),
                  Text("Account Type: Savings", style: TextStyle(color: Colors.white70, fontSize: 14)),
                  SizedBox(height: 20),
                  Row(
                    children: [
                      Icon(Icons.account_balance, color: Colors.white),
                      SizedBox(width: 10),
                      Text("John Doe", style: TextStyle(color: Colors.white, fontSize: 16)),
                    ],
                  ),
                ],
              ),
            ),

            SizedBox(height: 20),

            // Elevated Button for navigation
            Container(
              width: double.infinity,
              margin: EdgeInsets.symmetric(horizontal: 20),
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => AccountTypePage()),
                  );
                },
                child: Icon(Icons.add, size: 30, color: Colors.white),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF383838),
                  padding: EdgeInsets.symmetric(vertical: 20),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                ),
              ),
            ),
            SizedBox(height: 20),

            // Back to Profile Button
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ProfileScreen()),
                );
              },
              child: Text("Back to Profile"),
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFF383838),
                foregroundColor: Colors.white,
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        margin: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(30),
          boxShadow: [
            BoxShadow(
              color: Color(0xFF383838).withOpacity(0.1),
              blurRadius: 10,
              spreadRadius: 2,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(30),
          child: BottomNavigationBar(
            backgroundColor: Colors.white,
            selectedItemColor: Color(0xFF303330),
            unselectedItemColor: const Color(0xFF383838),
            showSelectedLabels: false,
            showUnselectedLabels: false,
            type: BottomNavigationBarType.fixed,
            items: [
              const BottomNavigationBarItem(
                icon: Icon(Icons.person_outline, color: Color(0xFF383838)),
                label: "",
              ),
              const BottomNavigationBarItem(
                icon: Icon(Icons.bookmark_border, color: Color(0xFF383838)),
                label: "",
              ),
              BottomNavigationBarItem(
                icon: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: Color(0xFF383838),
                  ),
                  child: const Icon(Icons.credit_card, color: Colors.white),
                ),
                label: "",
              ),
              const BottomNavigationBarItem(
                icon: Icon(Icons.account_balance, color: Color(0xFF383838)),
                label: "",
              ),
              const BottomNavigationBarItem(
                icon: Icon(Icons.calendar_today_outlined, color: Color(0xFF383838)),
                label: "",
              ),
            ],
            onTap: (index) {
              if (index == 0) {
                // Stay on ProfileScreen
              } else if (index == 1) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => CouponsPage()),
                );
              } else if (index == 2) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MembershipScreen()),
                );
              } else if (index == 3) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => BankingScreen()),
                );
              } else if (index == 4) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ReservationPage()),
                );
              }
            },
          ),
        ),
      ),
    );
  }
}

