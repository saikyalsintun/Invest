import 'package:flutter/material.dart';
import 'reservation.dart';
import 'History.dart';
import 'coupon.dart';
import 'profile.dart';
import 'banking.dart';
import 'SignOut.dart';

class MembershipScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.nightlight_round, color: Color(0xFF383838)),
          onPressed: () {},
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.exit_to_app, color: Color(0xFF383838)),
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => SignOut()));
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Color(0xFF383838),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'BALANCE',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    '399.95',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
            SizedBox(height: 16),
            // Updated Premium Membership Card
            Container(
              padding: EdgeInsets.all(50),
              decoration: BoxDecoration(
                gradient: LinearGradient(

                  colors: [Color(0xFF1C1C1C), Color(0xFF383838)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.3),
                    blurRadius: 15,
                    spreadRadius: 5,
                    offset: Offset(0, 5),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Premium Membership Card',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 24,
                      letterSpacing: 1.2,
                    ),
                  ),
                  SizedBox(height: 16),
                  Row(
                    children: [
                      Icon(Icons.credit_card, color: Colors.white70, size: 24),
                      SizedBox(width: 8),
                      Text(
                        '4307 0518 2430 1223',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 8),
                  Row(
                    children: [
                      Text(
                        'Exp 2/25',
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 16,
                        ),
                      ),
                      Spacer(),
                      Icon(Icons.access_time, color: Colors.white70, size: 20),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildOptionButton('Member Info'),
                _buildOptionButton('Activity', isPrimary: true),
              ],
            ),
            SizedBox(height: 16),
            _buildCardOption('Statement Request', 'Request'),
            SizedBox(height: 16),
            _buildCardOption('Activity', 'View'),
          ],
        ),
      ),
      bottomNavigationBar: _buildBottomNavBar(context),
    );
  }

  Widget _buildOptionButton(String text, {bool isPrimary = false}) {
    return Expanded(
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 8),
        padding: EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: isPrimary ? Color(0xFF383838) : Colors.white,
          borderRadius: BorderRadius.circular(16),
        ),
        alignment: Alignment.center,
        child: Text(
          text,
          style: TextStyle(
            color: isPrimary ? Colors.white : Color(0xFF383838),
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Widget _buildCardOption(String title, String buttonText) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Color(0xFFD0A557),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
          Container(
            padding: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Text(
              buttonText,
              style: TextStyle(color: Colors.black),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomNavBar(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 10,
              spreadRadius: 2,
              offset: Offset(0, 4)),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(30),
        child: BottomNavigationBar(
          currentIndex: 3,
          onTap: (index) {
            if (index == 0) {
              Navigator.push(context, MaterialPageRoute(builder: (context) => ProfileScreen()));
            } else if (index == 1) {
              Navigator.push(context, MaterialPageRoute(builder: (context) => CouponsPage()));
            } else if (index == 3) {
              Navigator.push(context, MaterialPageRoute(builder: (context) => BankingScreen()));
            } else if (index == 4) {
              Navigator.push(context, MaterialPageRoute(builder: (context) => ReservationPage()));
            }
          },
          backgroundColor: Colors.white,
          selectedItemColor: Color(0xFF383838),
          unselectedItemColor: Color(0xFF383838),
          showSelectedLabels: false,
          showUnselectedLabels: false,
          type: BottomNavigationBarType.fixed,
          items: [
            BottomNavigationBarItem(icon: Icon(Icons.person_outline), label: ""),
            BottomNavigationBarItem(icon: Icon(Icons.bookmark_border), label: ""),
            BottomNavigationBarItem(
              icon: Container(
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Color(0xFF383838),
                  shape: BoxShape.circle,
                ),
                child: Icon(Icons.credit_card, color: Colors.white),
              ),
              label: "",
            ),
            BottomNavigationBarItem(icon: Icon(Icons.account_balance), label: ""),
            BottomNavigationBarItem(icon: Icon(Icons.calendar_today_outlined), label: ""),
          ],
        ),
      ),
    );
  }
}
