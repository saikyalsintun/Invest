import 'package:flutter/material.dart';
import 'profile.dart';
import 'reservation.dart';
import 'coupon.dart';
import 'balance.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  _HistoryScreenState createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  bool showLastWeekTransactions = false;
  bool showTodayTransactions = false;
  List<String> todayTransactions = [
    "Objective - 200.00 ฿",
    "Transaction Code: 344455Vb12a\nTransfer to: Receiver\nTransaction Date: 23/2/2025",
    "Objective - 150.00 ฿",
    "Objective - 150.00 ฿"
  ];
  List<String> lastWeekTransactions = [
    "Objective - 300.00 ฿",
    "Transaction Code: 6578ABCd\nTransfer to: Sender\nTransaction Date: 15/2/2025"
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.nightlight_round, color: Colors.purple),
          onPressed: () {
            // Action when the leading icon is pressed
            // Navigator.push(
            //   context,
            //   MaterialPageRoute(builder: (context) => const ProfileScreen()),
            // );
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_none, color: Colors.purple),
            onPressed: () {
              // Action when the notification icon is pressed
              // Add your desired action here, like opening a notifications screen
            },
          ),
          const SizedBox(width: 16),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Transaction History",
                style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.purple),
              ),
              const SizedBox(height: 10),
              Expanded(
                child: todayTransactions.isEmpty && lastWeekTransactions.isEmpty
                    ? const Center(
                  child: Text(
                    "No history to show",
                    style: TextStyle(fontSize: 18, color: Colors.grey),
                  ),
                )
                    : ListView(
                  children: [
                    _buildExpandableTransactionSection(
                      "Today",
                      showTodayTransactions,
                          () {
                        setState(() {
                          showTodayTransactions = !showTodayTransactions;
                        });
                      },
                      todayTransactions,
                    ),
                    _buildExpandableTransactionSection(
                      "Last 1 Week Ago",
                      showLastWeekTransactions,
                          () {
                        setState(() {
                          showLastWeekTransactions = !showLastWeekTransactions;
                        });
                      },
                      lastWeekTransactions,
                    ),
                  ],
                ),
              ),
              Center(
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.purple,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20)),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 30, vertical: 12),
                  ),
                  onPressed: () {
                    setState(() {
                      todayTransactions.clear();
                      lastWeekTransactions.clear();
                    });
                  },
                  child: const Text("Delete Transaction & Cache",
                      style: TextStyle(color: Colors.white)),
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: _buildBottomNavBar(),
    );
  }

  Widget _buildExpandableTransactionSection(
      String title, bool isExpanded, VoidCallback onTap, List<String> transactions) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        InkWell(
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.bold, color: Colors.grey),
                ),
                Icon(
                  isExpanded ? Icons.arrow_drop_up : Icons.arrow_drop_down,
                  color: Colors.grey,
                ),
              ],
            ),
          ),
        ),
        if (isExpanded) ...[
          for (var transaction in transactions)
            _buildTransactionCard(transaction),
          const SizedBox(height: 10),
        ]
      ],
    );
  }

  Widget _buildTransactionCard(String description) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey.shade200,
        borderRadius: BorderRadius.circular(15),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Text(
              description,
              style: const TextStyle(color: Colors.black),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomNavBar() {
    return Container(
      margin: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 10, spreadRadius: 2, offset: Offset(0, 4)),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(30),
        child: BottomNavigationBar(
          currentIndex: 3,
          onTap: (index) {
            if (index == 0) {
              Navigator.push(context, MaterialPageRoute(builder: (context) => ProfileScreen()));
            } else if (index == 1) {
              Navigator.push(context, MaterialPageRoute(builder: (context) => CouponsPage()));
            } else if (index == 2) {
              Navigator.push(context, MaterialPageRoute(builder: (context) => MembershipScreen()));
            } else if (index == 4) {
              Navigator.push(context, MaterialPageRoute(builder: (context) => ReservationPage()));
            }
          },
          backgroundColor: Colors.white,
          selectedItemColor: Color(0xFF383838),
          unselectedItemColor: Color(0xFF383838),
          showSelectedLabels: false,
          showUnselectedLabels: false,
          type: BottomNavigationBarType.fixed,
          items: [
            BottomNavigationBarItem(icon: Icon(Icons.person_outline), label: ""),
            BottomNavigationBarItem(icon: Icon(Icons.bookmark_border), label: ""),
            BottomNavigationBarItem(
              icon: Container(
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Color(0xFF383838),
                  shape: BoxShape.circle,
                ),
                child: Icon(Icons.credit_card, color: Colors.white),
              ),
              label: "",
            ),
            BottomNavigationBarItem(icon: Icon(Icons.account_balance), label: ""),
            BottomNavigationBarItem(icon: Icon(Icons.calendar_today_outlined), label: ""),
          ],
        ),
      ),
    );
  }
}
