package com.example.cimso_development

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
